﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Sample.Models;
using Sample.Models.ViewModels;

namespace Sample.Controllers
{
    public class OrderController : Controller
    {
        private Cart cart;

        public OrderController(Cart aCart)
        {
            cart = aCart;
        }

        public IActionResult Index()
        {
            return View("Cart", new CartViewModel());
        }

        public RedirectToActionResult AddToCart(int productId, string returnUrl)
        {
            Product product = ProductRepository.storeProducts
            .FirstOrDefault(p => p.ProductID == productId);
            if (product != null)
            {
                cart.AddItem(product, 1);
            }
            return RedirectToAction("Index", new { returnUrl });
        }

        public ViewResult Checkout()
        {
            return View();
        }

    }
}